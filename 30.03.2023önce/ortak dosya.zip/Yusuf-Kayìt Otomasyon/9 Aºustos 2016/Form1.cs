﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9_Ağustos_2016
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            comboBox1.Text = "Meslek";
            comboBox2.Text = "Cinsiyet";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Text = "Meslek";
            comboBox2.Text = "Cinsiyet";
            comboBox1.Items.Add("ÖĞRETMEN");
            comboBox1.Items.Add("MEMUR");
            comboBox1.Items.Add("ÇİFTÇİ");
            comboBox2.Items.Add("ERKEK");
            comboBox2.Items.Add("KADIN");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != string.Empty && textBox2.Text != string.Empty)
            {
                if (listBox1.Text != "")
                {
                    int a = listBox1.SelectedIndex;
                    listBox2.Items.RemoveAt(a);
                    listBox3.Items.RemoveAt(a);
                    listBox4.Items.RemoveAt(a);
                    listBox5.Items.RemoveAt(a);
                    listBox1.Items.Clear();
                    for (int i = 0; i < listBox2.Items.Count; i++)
                    {
                        listBox1.Items.Add((i + 1) + ".");
                    }
                }
                listBox1.Items.Add(string.Format("{0}. ", listBox1.Items.Count + 1));
                listBox2.Items.Add(textBox1.Text.ToUpper());
                listBox3.Items.Add(textBox2.Text.ToUpper());
                listBox4.Items.Add(comboBox1.SelectedItem.ToString().ToUpper());
                listBox5.Items.Add(comboBox2.SelectedItem.ToString().ToUpper());

            }
            else
            {
                MessageBox.Show("LÜTFEN BÜTÜN ALANLARI DOLDURUNUZ", "!!! UYARI !!!");
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("HİÇ KAYIT BULUNAMADI", "!!!UYARI!!!");
            }
            else
            {
                if (listBox1.Text != "")
                {
                    int a = listBox1.SelectedIndex;
                    listBox2.Items.RemoveAt(a);
                    listBox3.Items.RemoveAt(a);
                    listBox4.Items.RemoveAt(a);
                    listBox5.Items.RemoveAt(a);
                    listBox1.Items.Clear();
                    for (int i = 0; i < listBox2.Items.Count; i++)
                    {
                        listBox1.Items.Add((i + 1) + ".");
                    }
                }
                else
                {
                    MessageBox.Show("LÜTFEN ÖNCE SEÇİM YAPINIZ", "!!!Uyarı!!!");
                }
            }

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a = listBox1.SelectedIndex;
            listBox2.SelectedIndex = a;
            listBox3.SelectedIndex = a;
            listBox4.SelectedIndex = a;
            listBox5.SelectedIndex = a;
        }
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a = listBox2.SelectedIndex;
            listBox1.SelectedIndex = a;
            listBox3.SelectedIndex = a;
            listBox4.SelectedIndex = a;
            listBox5.SelectedIndex = a;
        }
        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a = listBox3.SelectedIndex;
            listBox1.SelectedIndex = a;
            listBox2.SelectedIndex = a;
            listBox4.SelectedIndex = a;
            listBox5.SelectedIndex = a;
        }
        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a = listBox4.SelectedIndex;
            listBox2.SelectedIndex = a;
            listBox3.SelectedIndex = a;
            listBox1.SelectedIndex = a;
            listBox5.SelectedIndex = a;
        }
        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a = listBox5.SelectedIndex;
            listBox2.SelectedIndex = a;
            listBox3.SelectedIndex = a;
            listBox4.SelectedIndex = a;
            listBox1.SelectedIndex = a;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox1.Text == "")
            {
                MessageBox.Show("SEÇİLİ BİR KAYIT BULUNAMADI", "UYARI");
            }
            else
            {
                int A = listBox1.SelectedIndex;
                textBox1.Text = listBox2.Text;
                textBox2.Text = listBox3.Text;
                comboBox1.Text = listBox4.Text;
                comboBox2.Text = listBox5.Text;
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://plus.google.com/+yusufeyisan-photographer");
        }
    }
}
